#!/bin/bash

echo "🚀 Starting Vite app with NGINX..."
sudo systemctl restart nginx
